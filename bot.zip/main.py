
from aiogram import Bot, Dispatcher, executor, types
import asyncio
import logging
from aiogram.dispatcher.filters import Command, Text
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove, InputFile
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import keyboard as kb
import time
from contextlib import suppress
from aiogram.utils.exceptions import (MessageToEditNotFound, MessageCantBeEdited, MessageCantBeDeleted,
                                      MessageToDeleteNotFound)

api = '5015278268:AAFeVZtOgDtugdO6djxhVZ48iBuDx1GQH7A'

logging.basicConfig(level=logging.INFO)

bot = Bot(token=api)
dp = Dispatcher(bot, storage=MemoryStorage())


start_message = 'Привет! \n\
На связи чат-бот ВТБ - ваш помощник в вопросах социальных выплат. \
Я проанализирую Ваши данные и подберу для Вас индивидуальную выплату.\n\
Для этого пройдите, пожалуйста, небольшой опрос: '

class q1_states(StatesGroup):
	q1 = State()




@dp.message_handler(commands = ['start'])
async def starter(message: types.Message):
	await message.answer(start_message, reply_markup = kb.start_menu)


#Что положено при различных жизненных ситуациях
@dp.callback_query_handler(text_contains='st_but_1')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Хм... сейчас посмотрим: ', reply_markup=kb.sit_menu)
	

@dp.callback_query_handler(text_contains='sit_but_1')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	rubles = 18886.32
	await bot.send_message(callback_query.from_user.id, f'Размер выплаты за 1 ребенка составит {rubles} рублей.\
		Я могу рассчитать размер Вашей выплаты. Сколько у Вас будет детей?')
	await q1_states.q1.set()

@dp.message_handler(state=q1_states.q1)
async def q1_state(message: types.Message, state: FSMContext):
	try:
		count = int(message.text)
	except ValueError:
		await bot.send_message(message.from_user.id, 'Что-то пошло не так. Напишите число детей ')
	try:
		if count:
			rubles = 18886.32
			await bot.send_message(message.from_user.id, f'Вам положена выплата в размере {count * rubles} рублей', reply_markup=kb.start_menu)
			await state.reset_state()
	except UnboundLocalError:
		pass
#Какие льготы положены мне или моим родственникам
@dp.callback_query_handler(text_contains='st_but_2')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Укажите, пожалуйста, Ваш возраст.', reply_markup = kb.ages)




@dp.callback_query_handler(text_contains='age_2')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Состоите ли Вы в браке?', reply_markup = kb.brak)


#В браке?
@dp.callback_query_handler(text_contains='brak_no')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await no_pay(callback_query)

@dp.callback_query_handler(text_contains='brak_yes')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Укажите количество детей', reply_markup = kb.child)




#1-2 ребенка
@dp.callback_query_handler(text_contains='child_1')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Суммарный официальный доход на члена семьи меньше прожиточного минимума? (для г.Москвы - 18029)', reply_markup = kb.money)

#3+ детей
@dp.callback_query_handler(text_contains='child_2')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await no_pay(callback_query)

#нет детей
@dp.callback_query_handler(text_contains='child_3')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await no_pay(callback_query)





#Доход  больше минимума
@dp.callback_query_handler(text_contains='money_yes')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'В Вашей семье есть инвалиды?', reply_markup = kb.inv)

#Доход меньше минимума
@dp.callback_query_handler(text_contains='money_no')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Вам постараемся помочь позже, когда я получу инструкции', reply_markup = kb.start_menu)


#Как рассчитать?
@dp.callback_query_handler(text_contains='money_how')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Суммируйте весь официальный доход и считайте, пожалуйста.', reply_markup = kb.money)



#есть инвалиды
@dp.callback_query_handler(text_contains='inv_yes')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	msg = 'Вам положены следующие выплаты: \n\
	1. Ежемесячное пособие на детей в возрасте от 0 до 3 лет - 10951\n\
	2. Ежемесячное пособие на детей в возрасте от 8 до 18 лет - 4381\n\
	3. Ежемесячное пособие на детей в возрасте от 3 до 7 лет - 7725\n\n\
	Оформить можно на сайте https://www.gosuslugi.ru/ \
	Либо через ближайший МФЦ. Скоро я научусь определять ближайший к Вам отдел' 
	await bot.send_message(callback_query.from_user.id, msg, reply_markup = kb.start_menu)

#нет инвалидов
@dp.callback_query_handler(text_contains='inv_no')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	msg = 'Вам положены следующие выплаты: \n\
	1. Ежемесячное пособие на детей в возрасте от 0 до 3 лет - 10951\n\
	2. Ежемесячное пособие на детей в возрасте от 8 до 18 лет - 4381\n\
	3. Ежемесячное пособие на детей в возрасте от 3 до 7 лет - 7725\n\n\
	Оформить можно на сайте https://www.gosuslugi.ru/ \
	Либо через ближайший МФЦ. Скоро я научусь определять ближайший к Вам отдел' 
	await bot.send_message(callback_query.from_user.id, msg, reply_markup = kb.start_menu)

#вернуться в начало
@dp.callback_query_handler(text_contains='start_btn')
async def btn_1(callback_query: types.CallbackQuery):
	await bot.delete_message(chat_id=callback_query.from_user.id, message_id=callback_query.message.message_id)
	await bot.send_message(callback_query.from_user.id, 'Выберите вопрос', reply_markup=kb.start_menu)

async def no_pay(callback_query):
	await bot.send_message(callback_query.from_user.id, 'К сожалению, нет положенных выплат или мне не дали инструкцию. Перенаправляю в начало: ')
	time.sleep(1.5)
	await bot.send_message(callback_query.from_user.id, 'Выберите пункт:', reply_markup = kb.start_menu)

if __name__ == '__main__':
	loop = asyncio.get_event_loop()
	executor.start_polling(dp)